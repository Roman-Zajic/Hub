@echo off

:: BatchGotAdmin
:-------------------------------------
REM  --> Check for permissions
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"

REM --> If error flag set, we do not have admin.
if '%errorlevel%' NEQ '0' (
    echo Requesting administrative privileges...
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    set params = %*:"=""
    echo UAC.ShellExecute "cmd.exe", "/c %~s0 %params%", "", "runas", 1 >> "%temp%\getadmin.vbs"

    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
    pushd "%CD%"
    CD /D "%~dp0"
    set /P "UCNUMCAP=Enter number of capture devices you want to register: "
    echo "Installing %UCNUMCAP% capture devices ..."
    regsvr32 "UnityCaptureFilter32.dll" "/i:UnityCaptureDevices=%UCNUMCAP%"
    regsvr32 "UnityCaptureFilter64.dll" "/i:UnityCaptureDevices=%UCNUMCAP%"
    echo "Done"
:--------------------------------------
